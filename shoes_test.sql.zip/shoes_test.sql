--
-- Database: `shoes_test`
--
CREATE DATABASE IF NOT EXISTS `shoes_test` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `shoes_test`;

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `brands_stores`
--

CREATE TABLE `brands_stores` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `store_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `brands_stores`
--

INSERT INTO `brands_stores` (`id`, `brand_id`, `store_id`) VALUES
(1, 8, 11),
(2, 16, 22),
(3, 24, 33),
(4, 25, 34),
(5, 26, 34),
(6, 34, 45),
(7, 35, 46),
(8, 36, 46),
(9, 44, 57),
(10, 45, 58),
(11, 46, 58),
(12, 54, 59),
(13, 55, 60),
(14, 55, 61),
(15, 56, 72),
(16, 57, 73),
(17, 58, 73),
(18, 66, 74),
(19, 67, 75),
(20, 67, 76),
(21, 68, 87),
(22, 69, 88),
(23, 70, 88),
(24, 78, 89),
(25, 79, 90),
(26, 79, 91),
(27, 80, 102),
(28, 81, 103),
(29, 82, 103),
(30, 90, 104),
(31, 91, 105),
(32, 91, 106),
(33, 92, 117),
(34, 93, 118),
(35, 94, 118),
(36, 102, 119),
(37, 103, 120),
(38, 103, 121),
(39, 104, 132),
(40, 105, 133),
(41, 106, 133),
(42, 114, 134),
(43, 115, 135),
(44, 115, 136),
(45, 116, 147),
(46, 117, 148),
(47, 118, 148),
(48, 126, 149),
(49, 127, 150),
(50, 127, 151),
(51, 128, 162),
(52, 129, 163),
(53, 130, 163),
(54, 138, 164),
(55, 139, 165),
(56, 139, 166),
(57, 140, 177),
(58, 141, 178),
(59, 142, 178),
(60, 150, 179),
(61, 151, 180),
(62, 151, 181),
(63, 152, 192),
(64, 153, 193),
(65, 154, 193),
(66, 162, 194),
(67, 163, 195),
(68, 163, 196),
(69, 164, 207),
(70, 165, 208),
(71, 166, 208);

-- --------------------------------------------------------

--
-- Table structure for table `stores`
--

CREATE TABLE `stores` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `brands_stores`
--
ALTER TABLE `brands_stores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `stores`
--
ALTER TABLE `stores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=167;
--
-- AUTO_INCREMENT for table `brands_stores`
--
ALTER TABLE `brands_stores`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;
--
-- AUTO_INCREMENT for table `stores`
--
ALTER TABLE `stores`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=209;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
